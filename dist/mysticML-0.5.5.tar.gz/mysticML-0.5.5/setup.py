from setuptools import setup
setup(name='mysticML',
      version='0.5.5')
